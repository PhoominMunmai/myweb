<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP FUNCTION with parameter</title>
</head>
<body>
    <h2>This is first for PHP with Reference</h2>
    <?PHP
    /* Defining a PHP Function */
    function addFive($num): void{
        $num += 5;
    }
    /*Defining a PHP addSix Funtion */
    
    function addSix(&$num): void{
        $num += 6;
    }
    /* define original number */
    $orignum = 10;
    addFive($orignum);
    /* show result of addFive by value */
    echo "Original value is $orignum <br / > ";

    addSix($orignum);
    echo "Original Value is $orignum <br />";
    ?>
</body>
</html>