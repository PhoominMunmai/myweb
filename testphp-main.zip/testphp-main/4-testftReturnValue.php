<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP FUNCTION with parameter</title>
</head>
<body>
    <h2>This is first for PHP with return values</h2>
    <?PHP
    /* Defining a PHP Function */
    Function addFunction($num1, $num2) {
        $sum = $num1 + $num2;
        return $sum;
    }
    $return_value = addfunction(10, 20);
    
    echo "Return value from the function : $return_value";
    ?>
</body>
</html>